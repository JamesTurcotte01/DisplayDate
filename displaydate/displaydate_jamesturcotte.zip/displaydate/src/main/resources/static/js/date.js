/**
 * 
 */
 alert("This is the date template");
